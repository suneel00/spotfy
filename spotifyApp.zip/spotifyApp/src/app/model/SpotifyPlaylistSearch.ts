import { PlaylistSearch } from "./PlaylistSearch";

export class SpotifyPlaylistSearch{
    playlists! :PlaylistSearch
}