export class UserProfile{
    username!:string;
    firstName!:string;
    lastName!:string;
    password!:string;
    dateOfBirth!:string;
    email!:string;
}