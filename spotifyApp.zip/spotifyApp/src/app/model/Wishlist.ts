import { Track } from "./Track";

export class Wishlist{
    username!:string;
    tracks!: Track[];
}