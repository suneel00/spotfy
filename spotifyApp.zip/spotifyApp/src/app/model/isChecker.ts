export class isChecker{
    username!: string;
    role!: string;
}