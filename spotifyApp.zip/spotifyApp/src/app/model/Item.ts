import { Track } from './Track';
export class Item{
    added_at!:string;
    track!:Track;
    /*
    constructor(
        public addedAt:string,
        public track:Track
    ){}
    */
}