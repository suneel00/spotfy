import { Item } from './Item';
export class Tracks{
    items!: Item[];
    /*
    constructor(
        public items: Item[]
    ) {}
    */
}