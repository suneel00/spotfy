export class AuthAccessToken {
    message!: string;
    jwt_token!: string;
    role!: string;
    username!: string;
    /*
    constructor(
    public message: string,
    public jwtToken: string,
    public role: string,
    public username: string
    ) {}
    */
}