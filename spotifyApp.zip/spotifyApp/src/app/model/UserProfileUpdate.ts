export class ProfileUpdate{
    username!: string;
    firstName!: string;
    lastName!: string;
    dateOfBirth!: string;
    gender!: string;
}