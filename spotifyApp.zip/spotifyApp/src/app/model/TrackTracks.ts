import { Track } from "./Track";

export class TrackTracks{
    items!: Track[];
}