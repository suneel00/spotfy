export class ExternalUrls{
    spotify!: string;
    /*
    constructor(
        public spotify: string
    ) {}
    */
}