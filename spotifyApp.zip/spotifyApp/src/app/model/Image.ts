export class Image{
    height!: number;
    url!: String;
    width!: number;
    /*
    constructor(
        public height: number,
        public url: String,
        public width: number,

    ) { }
    */
}