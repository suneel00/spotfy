export class isExistsChecker{
    isExists!: boolean;
}