import { PlaylistItemsSearch } from "./PlaylistItemsSearch";

export class PlaylistSearch{
    items!: PlaylistItemsSearch[];
}