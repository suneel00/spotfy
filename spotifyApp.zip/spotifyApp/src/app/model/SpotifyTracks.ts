import { TrackTracks } from "./TrackTracks";

export class SpotifyTracks{
    tracks!: TrackTracks;
}